package com.example.demo.dto;

/** Wejście do tworzenia użytkownika. */
public class CreateUserRequest {
    public String name;
    public String email;
}
