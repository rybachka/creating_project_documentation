package com.example.demo.dto;

/** Prosty DTO użytkownika. */
public class UserResponse {
    public String id;
    public String name;
    public String email;
}
