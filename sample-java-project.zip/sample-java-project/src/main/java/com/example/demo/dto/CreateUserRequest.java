package com.example.demo.dto;


public class CreateUserRequest {
    public String name;
    public String email;
}
