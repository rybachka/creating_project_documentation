package com.example.demo;

import com.example.demo.dto.CreateUserRequest;
import com.example.demo.dto.UserResponse;
import org.springframework.web.bind.annotation.*;
import java.util.UUID;

/**
 * Operacje na użytkownikach.
 */
@RestController
@RequestMapping("/api/users")
public class UserController {

    /**
     * Zwraca użytkownika o podanym identyfikatorze.
     * Gdy nie znaleziono – zwraca 404.
     * @param id identyfikator użytkownika
     * @return obiekt użytkownika
     */
    @GetMapping("/{id}")
    public UserResponse getById(@PathVariable String id) {
        UserResponse u = new UserResponse();
        u.id = id;
        u.name = "Demo User";
        u.email = "demo@example.com";
        return u;
    }

    /**
     * Tworzy nowego użytkownika.
     * @param body dane wejściowe (name, email)
     * @return utworzony użytkownik
     */
    @PostMapping
    public UserResponse create(@RequestBody CreateUserRequest body) {
        UserResponse u = new UserResponse();
        u.id = UUID.randomUUID().toString().substring(0, 6);
        u.name = body.name;
        u.email = body.email;
        return u;
    }
}
