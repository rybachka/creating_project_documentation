package com.example.demo.dto;


public class UserResponse {
    public String id;
    public String name;
    public String email;
}
