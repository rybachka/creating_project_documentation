# Sample Java Project for AI Docs

Ten mini-projekt zawiera dwa kontrolery:
- `HelloController` (`GET /hello`)
- `UserController` (`GET /api/users/{id}`, `POST /api/users`)

Komentarze Javadoc posłużą do generowania opisów przez NLP.
