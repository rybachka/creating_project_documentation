package org.example.splitbooks.services;

import org.springframework.stereotype.Component;

@Component
public interface FriendSuggestionService {
}
