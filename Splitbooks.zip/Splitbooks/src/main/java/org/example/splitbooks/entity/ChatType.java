package org.example.splitbooks.entity;

public enum ChatType {
        PRIVATE,
        GROUP
}
