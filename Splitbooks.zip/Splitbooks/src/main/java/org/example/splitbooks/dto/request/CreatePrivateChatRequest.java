package org.example.splitbooks.dto.request;

import lombok.Data;

@Data
public class CreatePrivateChatRequest {
    private Long otherParticipantId;
   
}
