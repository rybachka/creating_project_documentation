package org.example.splitbooks.entity;

public enum GroupChatType {
    ANONYMOUS_ONLY,
    PUBLIC_ONLY,
    MIXED
}
