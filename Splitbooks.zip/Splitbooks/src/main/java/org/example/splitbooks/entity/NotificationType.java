package org.example.splitbooks.entity;

public enum NotificationType {
    MATCH,
    SWIPE,
    FOLLOW,
    CHAT
}
