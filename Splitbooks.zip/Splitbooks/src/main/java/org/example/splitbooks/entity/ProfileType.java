package org.example.splitbooks.entity;

public enum ProfileType {
        ANONYMOUS,
        PUBLIC
}
