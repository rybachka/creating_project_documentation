package org.example.splitbooks.entity;

public enum SearchType {
    BY_TITLE,
    BY_AUTHOR,
    BY_GENRE
}