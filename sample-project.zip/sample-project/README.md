# Sample Test Project

Ten projekt służy jedynie do testowania uploadu ZIP w aplikacji "Tworzenie dokumentacji projektu z wykorzystaniem metod sztucznej inteligencji".
