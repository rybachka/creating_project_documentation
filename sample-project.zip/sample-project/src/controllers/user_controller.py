# przykładowy plik źródłowy – nieistotny dla testu
def get_user(id):
    return {"id": id, "name": "Jan"}
